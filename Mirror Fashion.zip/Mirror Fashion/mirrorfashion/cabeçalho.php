<title><?php  print $cabeçalho_title;?></title>

<header class="container">
        <h1><img src="img\logo.png" alt="Mirror fashion" id="logo"></h1>
                <p class="sacola">
                    nenhum item sacola de compras
                </p>
                <nav  class="menu-opçoes">
                    <ul>
                        <li><a href="#">Sua conta</a></li>
                        <li><a href="#"> Lista de desejos</a></li>
                        <li><a href="#">Cartão fidelidade</a></li>
                        <li><a href="sobre.php">Sobre</a></li>
                        <li><a href="#">Ajuda</a></li>
                    </ul>
                </nav>
</header>