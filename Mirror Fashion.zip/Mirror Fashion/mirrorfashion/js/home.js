$('.novidades   button').click(function(){
    $('.novidades').addClass('painel-aberto');
});


$('.Mais-vendidos   button').click(function(){
    $('.Mais-vendidos').addClass('painel-aberto');
});

