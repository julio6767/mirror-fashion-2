<footer>

<div class="container">
    <img src="img\logo-rodape.png" alt="logo da mirrorfashion">
    <ul	class="social">
      <li><a	href="http://facebook.com/mirrorfashion">Facebook</a></li>
      <li><a	href="http://twitter.com/mirrorfashion">Twitter</a></li>
      <li><a	href="http://plus.google.com/mirrorfashion">Google+</a></li>
      </ul>
 
</div>

</footer>
